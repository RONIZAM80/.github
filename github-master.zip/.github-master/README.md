# .github

These are the [default community health files](https://help.github.com/en/articles/creating-a-default-community-health-file-for-your-organization) for the Microsoft organization on GitHub.

# Contributing

Microsoft projects adopt the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/). For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.
